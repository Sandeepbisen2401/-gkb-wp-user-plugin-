<?php
//insert data file
//insert function
//echo plugins_url();die;
//define("PLUGIN_URL",plugins_urL());
wp_enqueue_media();
	?>
<!DOCTYPE html>
<html>
<head>
	<title>Create-users page:</title>
	<h1>Create-users page</h1>
</head>
<body>
	<form method="POST">
	<div class="first">
	<label>First Name</label>
	<input type="text" name="First_Name" required>
	<label>Last Name</label>
	<input type="text" name="Last_Name" required>
	<label>Enter Email</label>
	<input type="email" name="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required><br>
	</div>
	<div class="second">
	<label>Select Hobbies</label><br>
	 <input type="checkbox" name="Hobbies[]" value="TV" id="TV">TV
     <input type="checkbox" name="Hobbies[]" value="Reading" id="Reading">Reading
     <input type="checkbox" name="Hobbies[]" value="Coding" id="Coding">Coding
     <input type="checkbox" name="Hobbies[]" value="Skiing" id="Skiing">Skiing
 </div>
 <div class="third">
     <label>Gender</label><br>
     <input type="radio" name="Gender" value="Male" required/>Male
     <input type="radio" name="Gender" value="Female" required/>Female
     </div>
     <div class="fourth">
     <label>Upload Image</label><br>
	 <input type="button" value="Upload Image" id="Upload-img" required>
	 <img src="" style="height: 80px; width: 80px" id="demo_image" required/ >
	 <input type="hidden" name="demo_cover_image" id="demo_cover_image" required/>
	 </div>
	 <input type="submit" name="insert" value="Submit" class="submit">
	 <a href="<?php echo admin_url('admin.php?page=Create_user'); ?>"><input type="button" name="Cancel" value="Cancel" class="submit"></a>
	</form>
</body>
</html>
<?php


//Login code.....
function create_users()
{
	if(isset($_POST['insert']))
	{
		$F=$_POST['First_Name'];
		$L=$_POST['Last_Name'];
		$E=$_POST['Email'];
		$select=$_POST['Hobbies'];
		$chk="";
		foreach($select as $chk1)
		{
			$chk.=$chk1;
		}
		$G=$_POST['Gender'];
		$I=$_POST['demo_cover_image'];
		global $wpdb;
		$query=$wpdb->insert("wp_demo_plugin_db",array("First_Name"=>$F,"Last_Name"=>$L,"Email"=>$E,"Hobbies"=>$chk1,"Gender"=>$G,"demo_cover_image"=>$I));
		if($query==true)
		{
			echo '<script language="javascript">';
            echo 'alert("Data Successfully Saved")';
            echo '</script>';
		}
		else
		{
			echo '<script language="javascript">';
            echo 'alert("Something Wrong!!")';
            echo '</script>';
		}


	}
	
	
}
?>

