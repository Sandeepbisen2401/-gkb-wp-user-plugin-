<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<style>
		.Table{
			border-collapse: collapse;
			background-color: darkseagreen;
      text-align: center;
		}
		th {
    background-color: cadetblue;
}
.red {
    background-color: red;
    border: none;
    padding: 10px;
    border-radius: 5px;
    color: white;
}
.green {
    background-color: green;
    padding: 10px;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}
	</style>
	<script>
		function confirm() {
  alert("Are you sure!");
}
	</script>
</head>
<body>
<?php
//Pagination code
function DBP_display_table(){
	?>
<form method="POST" action="<?php echo admin_url("admin.php?page=Getdata_form")?>">
	<?php
	if(isset($_POST['Delete']))
	{
		global $wpdb;
		$result=$wpdb->delete("wp_demo_plugin_db",
			array(
				'id'=>$_POST['Delete']
			)
		);
	}
   global $wpdb;
   $sql=$wpdb->get_results("select * from wp_demo_plugin_db");
   
	?>
	<h2>List Users Page</h2>
	<table style="width:100%" border="1px" class="Table">
  <tr>
  	<th>No</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Email</th>  
    <th>Hobbies</th>
    <th>Gender</th>
    <th>Images</th>
    <th>Update</th>
    <th>Delete</th>
  </tr>
<?php
foreach($sql as $wp_dbp_tb_login){?>
	<tr>
		<td style="width:5%"><?php echo $id=$wp_dbp_tb_login->id;?></td>
		<td style="width:10%"><?php echo $wp_dbp_tb_login->First_Name; ?></td>
		<td style="width:10%"><?php echo $wp_dbp_tb_login->Last_Name; ?></td>
		<td style="width:20%"><?php echo $wp_dbp_tb_login->Email; ?></td>
		<td style="width:10%"><?php echo $wp_dbp_tb_login->Hobbies; ?></td>
		<td style="width:10%"><?php echo $wp_dbp_tb_login->Gender; ?></td>
		<td><img src="<?php echo $wp_dbp_tb_login->demo_cover_image;?>" style="height:100px; width:100px;"/></td>
		<td style="width:10%"><a href="<?php echo admin_url('admin.php?page=updatedata_form&id='.$id);?>" class="green">Update</a></td>
		<td><button name="Delete" class="red" value="<?php echo $id;?>" onclick="confirm();">Delete</button></td>
	</tr>
	</body>
</html>
	<?php}
	?>
	
	<?php

}}
?>

