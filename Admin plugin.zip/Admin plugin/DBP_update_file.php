<?php
//Create form
//get id form address bar
//retrive data from databse
//write update query
//add update event

$DBP_id=$_GET['id'];
//DBP_update_form($DBP_id);
function DBP_update_form($DBP_id)
{
	DBP_update($DBP_id);

	global $wpdb;
	$sql=$wpdb->get_results("select * from wp_demo_plugin_db where id = $DBP_id");
	foreach($sql as $wp_dbp_tb_login)
	{
		 $F=$wp_dbp_tb_login->First_Name;
		 $L=$wp_dbp_tb_login->Last_Name;
		 $E=$wp_dbp_tb_login->Email;
		 $G=$wp_dbp_tb_login->Gender;
		 $chk1=$wp_dbp_tb_login->Hobbies;
	}
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Update form</title>
		<h1>Update form</h1>
		<style>
			label{
				font-family: verdana;
                font-size: 15px;
                color: black;
			}
			div.first{
				float: left;
				width: 97%;
			}
			div.first input{
				width: 23%;
			}
			h5 {
    color: green;
    font-size: 15px;
    font-family: verdana;
    text-transform: capitalize;
}
		</style>
	</head>
	<body>
	<form method="POST">
	<div class="first">
	<label>First_Name</label>
	<input type="text" name="First_Name" value="<?php echo $F;?>"/>
	<label>Last_Name</label>
	<input type="text" name="Last_Name" value="<?php echo $L;?>"/>
	<label>Enter email</label>
	<input type="email" name="Email" value="<?php echo $E;?>"/>
    </div>
     <div class="second">
     <label>Select Hobbies</label><br>
	 <input type="checkbox" name="Hobbies[]" value="TV">TV
     <input type="checkbox" name="Hobbies[]" value="Reading">Reading
     <input type="checkbox" name="Hobbies[]" value="Coding">Coding
     <input type="checkbox" name="Hobbies[]" value="Skiing ">Skiing
     </div>
      <div class="third">
      <label>Gender</label>
     <input type="radio" name="Gender" value="Male"/>Male
     <input type="radio" name="Gender" value="Female"/>Female<br>
     </div>
	<input type="submit" name="submit" value="Update" class="submit">
	<a href="<?php echo admin_url('admin.php?page=Getdata_form'); ?>"><input type="button" name="Return" value="Back"   class="submit"></a>
	</form>	
	</body>
	</html>
	<?php
}

Function DBP_update($DBP_id)
{
	if(isset($_POST['submit'])){
	global $wpdb;

        $F=$_POST['First_Name'];
		$L=$_POST['Last_Name'];
		$E=$_POST['Email'];
		$G=$_POST['Gender'];
		$select=$_POST['Hobbies'];
		$chk="";
		foreach($select as $chk1)
		{
			$chk.=$chk1;
		}
		$wpdb->update("wp_demo_plugin_db",
			array("First_Name"=>$F,
				"Last_Name"=>$L,
				"Email"=>$E,
				"Gender"=>$G,
				"Hobbies"=>$chk1,
			),array(
				"id"=>$DBP_id
			)
		);
		echo "<h5>Update succesfully!</h5>";

}}
?>






