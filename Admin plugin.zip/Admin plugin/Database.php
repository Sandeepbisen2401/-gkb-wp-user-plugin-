<?php
//Creating automatically table in wpdb

function DBP_tb_create()
{
	//step 1
	global $wpdb;
	$DBP_tb_name=$wpdb->prefix ."wp_demo_plugin_db";

	//step 2
	$DBP_query="CREATE TABLE $DBP_tb_name(
	id int(10) NOT NULL AUTO_INCREMENT,
	First_Name varchar(100) DEFAULT '',
	Last_Name varchar(100) DEFAULT '',
	Email varchar(100) DEFAULT'',
	Hobbies varchar(100) DEFAULT '',
	Gender varchar(100) DEFAULT '',
	demo_cover_image text(100) DEFAULT'',
	PRIMARY KEY(id)
)";
//step 3
require_once(ABSPATH ."wp-admin/includes/upgrade.php");
dbDelta($DBP_query);

}
?>
