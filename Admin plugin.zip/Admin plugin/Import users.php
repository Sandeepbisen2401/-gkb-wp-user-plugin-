<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	
	<style>
		.second {
    background-color: cornflowerblue;
    border: none;
    padding: 5px;
    margin: 5px;
    width: 10%;
    border-radius: 5px;
    color: white;
    text-transform: capitalize;
   }
        .Table{
			border-collapse: collapse;
			background-color: darkseagreen;
      text-align: center;
		}
		thead {
    background-color: cadetblue;
}
	</style>
</head>
<body>

</body>
</html>

<?php 
    global $wpdb;
	$DBP_tb_name=$wpdb->prefix ."demo_plugin_db";

	if(isset($_POST['butimport']))
	{
		$extension = pathinfo($_FILES['import_file']['name'],PATHINFO_EXTENSION);

		if(!empty($_FILES['import_file']['name']) && $extension == 'csv')
		{
			$totalInserted=0;
			$csvFile=fopen($_FILES['import_file']['tmp_name'],'r');

			fgetcsv($csvFile);//skipping header row

			while (($csvData = fgetcsv($csvFile))!==false) {
				$csvData=array_map('utf8_decode',$csvData);

				$dataLen=count($csvData);

				if(!($dataLen)==3)
				{
					continue;
				}

				$First_Name=trim($csvData[0]);
				$Last_Name=trim($csvData[1]);
				$Email=trim($csvData[2]);

				if(!empty($First_Name) && !empty($Last_Name) && !empty($Email))
				{
					$cntSQL="SELECT count(*) as count FROM {$DBP_tb_name} WHERE Email='".$Email."'";
					$record=$wpdb->get_results($cntSQL,OBJECT);
					if($record[0]->count==0)
					{
						$wpdb->insert($DBP_tb_name,array(
							"First_Name"=>$First_Name,
							"Last_Name"=>$Last_Name,
							"Email"=>$Email
						));

						if($wpdb->insert_id>0)
						{
							$totalInserted++;
						}
					}
				}
			}
			 echo "<h3 style='color:green;'>Total successfully imported:".$totalInserted."</h3>";

		}else{
			echo "<h3 style='color:red;'>Invalid Extension</h3>";
		}
	}
?>
<h2>Import user data from a CSV</h2>
<!--form-->
<form method="POST" action="<?=$_SERVER['REQUEST_URI']?>" enctype="multipart/form-data">
	<input type="file" name="import_file" class="first">
	<input type="submit" name="butimport" value="import" class="second">
</form>
 <table width="100%" border="1" style="border-collapse: collapse;" class="Table">
 	<thead>
 		<tr>
 			<td>No</td>
 			<td>First Name</td>
 			<td>Last Name</td>
 			<td>Email</td>
 		</tr>
 	</thead>
 	<tbody>
 		<?php
 		$entrieslist=$wpdb->get_results("SELECT * FROM ".$DBP_tb_name." ORDER BY id DESC");
 		if(count($entrieslist)>0){
 			$count=0;
 			foreach ($entrieslist as $entry) {
 				$id=$entry->id;
 				$First_Name =$entry->First_Name;
 				$Last_Name =$entry->Last_Name;
 				$Email  =$entry->Email;

 				echo "<tr>
 				<td>".++$count."</td>
 				<td>".$First_Name."</td>
 				<td>".$Last_Name."</td>
 				<td>".$Email."</td>
 				</tr>";

 				// code...
 			}

 		}else{
 			echo "<tr><td colspan='5'>No record found.</tr></td>";
 		}

 		 ?>
 	</tbody>
 </table>