<?php
/*
* Plugin Name:Demo-Plugin
* Plugin URL:www.sandeepbisen.blogspot.com
* Description:This is demo-plugin...
* version:1.10
* Author:Sandeep Bisen
* Author url:www.sandeepbisen.blogspot.com
*/
// define absolute path to avoid direct access
if(!defined('ABSPATH'))
{
	define('ABSPATH',dirname(__FILE__) ,'/');
}

//file include
include_once("Database.php");
register_activation_hook(__FILE__,"DBP_tb_create");
//ADD MENU IN ADMIN PANEL
function admin_menu()
{
	add_menu_page(
		"Create_user",
		"Create user",
		"manage_options",
		"Create_user",
		"Create_user_fun",
		"dashicons-admin-users",
		80
	);
	add_submenu_page("Create_user",
		"Import_users ",
		"Import users ",
		"manage_options",
		"register_form",
		"Import_users_function"//callback function
	);
	add_submenu_page("Create_user",
		"Updeatdata",
		"",
		"manage_options",
		"updatedata_form",
		"Update_data_function"//callback function
	);
	add_submenu_page("Create_user",
		"List_users",
		"List users",
		"manage_options",
		"Getdata_form",
		"List_users_function"//callback function
	);

}
add_action("admin_menu","admin_menu");

function Create_user_fun()
{
	include_once("Create user.php");	
	create_users();
}
function List_users_function()
{
	include_once("DBP_get_data.php");
	DBP_display_table();
}
function Update_data_function()
{
	include_once("DBP_update_file.php");
	DBP_update_form($DBP_id);
}
function Import_users_function()
{
	include_once("Import users.php");
	
}
if(!defined("ABSPATH"))
	exit;
if(!defined("DEMO_PLUGIN_DIR_PATH"))
	define("DEMO_PLUGIN_DIR_PATH",plugin_dir_path(__FILE__));

if(!defined("DEMO_PLUGIN_URL"))
	define("DEMO_PLUGIN_URL",plugins_url()."/ADMIN PLUGIN");

function demp_plugin()
{
	wp_enqueue_script("script",DEMO_PLUGIN_URL."/script.js");
	wp_enqueue_style("style",DEMO_PLUGIN_URL."/main_style.css");
}

add_action("init","demp_plugin");
//echo DEMO_PLUGIN_URL;
?>