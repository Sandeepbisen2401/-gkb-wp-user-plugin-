jQuery(document).ready(function()
{
jQuery("#Upload-img").on("click",function()
{
	var image = wp.media({
		title:"Upload Image For Demo-Plugin",
		multiple:false
	}).open().on("select",function(e){
		var upload_image=image.state().get("selection").first();
		//console.log(upload_image.toJSON());
		var image_data=upload_image.toJSON();
		jQuery("#demo_image").attr("src",image_data.url);
		jQuery("#demo_cover_image").val(image_data.url);
	});
});
});

